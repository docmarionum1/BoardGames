Jeremy Neiman

Baseball Diamond Dice
=====================

Included in this archive:

- A PDF of the rules
- A spreadsheet with the batter cards and their stats
- A spreadsheet with the starting pitchers and their abilities
- A spreadsheet with the relief pitchers and their abilities
- A photograph of the game board
- A photograph with each type of card's front and back.